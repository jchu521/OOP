package EmployeeAndCustomerManagement;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//import java.text.SimpleDateFormat;

abstract public class Person {
	/*
	 * Basic information about all persons is person ID, name, date of birth, address, and telephone number.
	 */
	private ArrayList<Person> persons = new ArrayList<Person>();
	private int id;
	private String name,address,phone;
	private Date birth;
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");

	//constructor 
	public Person(int id, String name, String address, String phone, Date birth){
		this.id = id;
		this.name = name;
		this.birth = birth;
		this.address = address;
		this.phone = phone;
	}
	
	//Display method 
	protected void displayPersonInfo(){
		
		System.out.println("ID: " + id);
		System.out.println("name: " + name);
		System.out.println("birth: " + sdf.format(birth));
		System.out.println("address: " + address);
		System.out.println("phone: " + phone);
	}
	// update person info
	protected abstract void updatePersonInfo();
	
	//Search and display information of a person by id
	public void searchPersonById(int id){
		for(Person p: persons){
			if(this.id == id){
				displayPersonInfo();
				//System.out.println("1111111111111111111111");
			}
		}
	}
	public String getName(){
		return name;
	}
	public int getId(){
		return id;
	}




}