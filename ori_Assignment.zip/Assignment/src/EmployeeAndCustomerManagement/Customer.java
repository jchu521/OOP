package EmployeeAndCustomerManagement;

import java.util.ArrayList;
import java.util.Date;

public class Customer extends Person{
	/*
	 * For customers, information such as licence number, age and license expiry date is maintained.
	 */
	private ArrayList<Person> persons = new ArrayList<Person>();
	private String licenceNum;
	private int age;
	private Date licenceExpiryDate;
	//Constructor
	public Customer(int id, String name, String address, String phone, Date birth, String licenceNum, int age  ,Date licenceExpiryDate){
		super(id, name,address,phone, birth);
		this.licenceNum = licenceNum;
		this.age = age;
		this.licenceExpiryDate = licenceExpiryDate;
	}
	

	//display customer detail

	
	// TODO Auto-generated method stub
	//display customer detail
	public void customerDetail(){
		
		System.out.println("Customer info: ");
		displayPersonInfo();
		System.out.println("Licence Number: " + licenceNum);
		System.out.println("Age: " + age);
		System.out.println("Licence Expiry Date: " + sdf.format(licenceExpiryDate));
		System.out.println("\n");

	}

	//setter
	public void setLicenceExpiryDate(Date date){
		this.licenceExpiryDate = date;
	}
	@Override
	protected void updatePersonInfo() {
		// TODO Auto-generated method stub
		
	}

}