package UnitTest;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import EmployeeAndCustomerManagement.Customer;
import EmployeeAndCustomerManagement.Employee;
import EmployeeAndCustomerManagement.Person;
import RentalManagement.Rental;
import StockManagement.Builder;
import StockManagement.Guitar;
import StockManagement.Type;
import StockManagement.Wood;

public class TestingRentalManagement {
	Employee employee;
	ArrayList<Guitar> guitars;
	ArrayList<Rental> rentals;
	ArrayList<Person> persons;
	Customer customer;
	Guitar guitar1;
	Guitar guitar2;
	Guitar guitar3;
	static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	@Before
	public void setUp() throws Exception {
		employee = new Employee(1, "Ben", "Auckland", "0123456",sdf.parse("1990-11-01"),"Auckland", "0987654", "user1", "pwd1", true);
		guitars = new ArrayList<Guitar>();
		rentals = new ArrayList<Rental>();
		persons = new ArrayList<Person>();
		customer = new Customer(3, "Chris", "Auckland2", "0111111",sdf.parse("1995-4-25"),"L45789", sdf.parse("2018-11-14"));
		guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Stratocaster", Type.ACOUSTIC, Wood.ADIRONDACK, Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2011, 40,"Blue");
		guitar3 = new Guitar("3", 400, Builder.RYAN, "Stratocaster",Type.ACOUSTIC,Wood.ALDER,Wood.BRAZILIAN_ROSEWOOD,2016,30,"Black");
		persons.add(employee);
		persons.add(customer);
	}

	@After
	public void tearDown() throws Exception {
		employee =null;
	}

	@Test
	public void testRentGuitars() {
		System.out.println("testing Rent Guitars method");
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		assertFalse("Testing wrong serial num",employee.rentGuitar("A1", 3, guitars, rentals,persons));
		assertFalse("Testing wrong id",employee.rentGuitar("A123c", 10, guitars, rentals,persons));
		assertTrue(employee.rentGuitar("A123c", 3, guitars, rentals,persons));
	}
	@Test
	public void testReturnGuitars() {
		System.out.println("testing Return Guitars method");
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		employee.rentGuitar("A123c", 3, guitars, rentals,persons);
		assertFalse("Testing wrong serial num",employee.returnGuitar("A1", rentals));
		assertTrue(employee.returnGuitar("A123c", rentals));
	}
	@Test
	public void testguitarsRentedByCusotmer() {
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		employee.rentGuitar("A123c", 3, guitars, rentals,persons);
		int number = employee.guitarsRentedByCusotmer(3, rentals, persons);
		//testing  1 guitar
		assertEquals(1,number);
		//testing  2 guitars
		employee.rentGuitar("B784", 3, guitars, rentals,persons);
		number = employee.guitarsRentedByCusotmer(3, rentals, persons);
		assertEquals(2,number);
	}
}
