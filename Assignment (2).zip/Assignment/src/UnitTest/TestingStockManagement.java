package UnitTest;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import EmployeeAndCustomerManagement.Employee;
import StockManagement.Builder;
import StockManagement.Guitar;
import StockManagement.Type;
import StockManagement.Wood;

public class TestingStockManagement {
	Employee employee;
	ArrayList<Guitar> guitars;
	Guitar guitar1;
	Guitar guitar2;
	Guitar guitar3;
	static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	@Before
	public void setUp() throws Exception {
		employee = new Employee(1, "Ben", "Auckland", "0123456",sdf.parse("1990-11-01"),"Auckland", "0987654", "user1", "pwd1", true);
		guitars = new ArrayList<Guitar>();
		guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Stratocaster", Type.ACOUSTIC, Wood.ADIRONDACK, Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2011, 40,"Blue");
		guitar3 = new Guitar("3", 400, Builder.RYAN, "Stratocaster",Type.ACOUSTIC,Wood.ALDER,Wood.BRAZILIAN_ROSEWOOD,2016,30,"Black");
	}

	@After
	public void tearDown() throws Exception {
		employee = null;
		guitars = null;
		guitar1 = null;
		guitar2 = null;
		guitar3 = null;
	}

	@Test
	public void testAddGuitar() {
		Guitar guitar = employee.searchGuitarBySerialNumber("123", guitars);
		assertEquals("Testing guitar1: ", null ,guitar);
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitar = employee.searchGuitarBySerialNumber("A123c", guitars);
		//testing guitar1
		assertEquals("Testing guitar1: ", "A123c" ,guitar.getSerialNumber());
		//testing guitar2
		guitar = employee.searchGuitarBySerialNumber("B784", guitars);
		assertEquals("Testing guitar2: ", "B784" ,guitar.getSerialNumber());
	}
	@Test
	public void testsearchGuitarBySerialNumber() {
		//add three guitars
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		Guitar guitar = employee.searchGuitarBySerialNumber("123", guitars);
		assertEquals("Testing no guitar in list: ", null ,guitar);
		
		guitar = employee.searchGuitarBySerialNumber("A123c", guitars);
		assertEquals("Testing guitar1: ", guitar1 ,guitar);
		guitar = employee.searchGuitarBySerialNumber("3", guitars);
		assertEquals("Testing guitar3: ", guitar3 ,guitar);
	}
	//test Display a list of guitars available for rent
	@Test
	public void testGuitarsAvailableForRent() {
		//test no guitar available for rent
		assertEquals("Test one guitar1","No guitar available for rent",employee.guitarsAvailableForRent(guitars) );
		
		guitars.add(guitar1);
		//testing one guitar
		String expected1 = "1.\n"+"Serial Number: A123c" + "\nModel: Stratocaster"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n";
		
		assertEquals("Test one guitar1",expected1,employee.guitarsAvailableForRent(guitars) );
		//System.out.println(employee.guitarsAvailableForRent(guitars));
		guitars.add(guitar2);
		//testing two guitars
		String expected2 = "1.\n"+"Serial Number: A123c" + "\nModel: Stratocaster"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n"+ "2.\n"+"Serial Number: B784\nModel: Telecaster\nType: electric\nBuilder: Fender\nColour: Blue\nTopWood: Cedar\nBackWood: Sitka\nYear of manufacture: 2011\nPrice: 100.0\nRent rate per day: 40.0\nStatus: Shop\n";
		assertEquals("Test two guitars",expected2,employee.guitarsAvailableForRent(guitars) );
		//System.out.println(employee.guitarsAvailableForRent(guitars));

	}
	@Test
	public void testSearchGuitarByModel() {
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		//test 
		assertEquals("Testing with no match model","Not Found, Model: 123",employee.searchGuitarsByModel("123", guitars) );
		String expected = "1.\nModel: Telecaster\nBuilder: Fender\nColour: Blue\nStatus: Shop\n";
		assertEquals("Testing model Telecaster",expected,employee.searchGuitarsByModel("telecaster", guitars) );
		//System.out.println(employee.searchGuitarsByModel("telecaster",guitars));
		expected ="1.\nModel: Stratocaster\nBuilder: Collings\nColour: Red\nStatus: Shop\n2.\nModel: Stratocaster\nBuilder: Ryan\nColour: Black\nStatus: Shop\n";
		assertEquals("Testing model stratocaster",expected,employee.searchGuitarsByModel("stratocaster", guitars) );
		//System.out.println(employee.searchGuitarsByModel("stratocaster",guitars));
	}
	@Test
	public void testDisplayGuitarBySerialNumber() {
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		//test 
		assertEquals("Testing with no match serial num","Guitar not found ",employee.displayGuitarBySerialNumber("123", guitars) );
		String expected = "Search for serialNumber: 3\nColour: Black\nBackwood: Alder\nTopWood: Brazilian Rosewood\nBuilder: Ryan\nType: acoustic\nStatus: Shop\n";
		assertEquals("Testing guitar3",expected,employee.displayGuitarBySerialNumber("3", guitars) );
		//System.out.println(employee.displayGuitarBySerialNumber("3",guitars));

	}
	@Test
	public void testSearchGuitarsByYearOfManufacture() {
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		//test 
		assertEquals("Testing with no match year","Not Found, no match year : 2000",employee.searchGuitarsByYearOfManufacture(2000, guitars) );
		String expected = "1.\nSearch for year: 2011\nModel: Stratocaster\nBackwood: Adirondack\nTopWood: Indian Rosewood\nBuilder: Collings\n2.\nSearch for year: 2011\nModel: Telecaster\nBackwood: Sitka\nTopWood: Cedar\nBuilder: Fender\n";
		assertEquals("Testing year 2011",expected,employee.searchGuitarsByYearOfManufacture(2011, guitars) );
		//System.out.println(employee.searchGuitarsByYearOfManufacture(2011,guitars));
	}
	@Test
	public void testUpdateGuitar() {
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		employee.updateInfo("3", guitars);
		Guitar g = employee.searchGuitarBySerialNumber("3", guitars);
		assertEquals(250,g.getPrice(),0.0);
		assertEquals(10,g.getRent(),0.0);
	}
}
