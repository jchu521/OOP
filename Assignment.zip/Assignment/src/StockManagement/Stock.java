package StockManagement;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import EmployeeAndCustomerManagement.Customer;
import EmployeeAndCustomerManagement.Employee;
import EmployeeAndCustomerManagement.Person;
import RentalManagement.Rental;

public class Stock {
	private static ArrayList<Guitar> guitars  = new ArrayList<Guitar>();
	private static ArrayList<Rental> rentals  = new ArrayList<Rental>();
	private static ArrayList<Employee> employees = new ArrayList<Employee>(); 
	private static ArrayList<Person> persons = new ArrayList<Person>(); 
	static Scanner scan = new Scanner(System.in);
	static Calendar c = Calendar.getInstance();
	static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	//main method for testing
	public static void main(String[] args) throws ParseException{
		//testing part 1
		System.out.println("Part One: \n");
		// 3-3 Add details of a new employee
		Employee em = addEmployee();
		//Add details of a new customer
		addCustomer();
		// 1-1 Add a new guitar information 
		addGuitar();
		
		//Display guitars
		em.displayGuitarsInfo(guitars);
		
		// 1-2 Display a list of guitars available for rent
		isAvailableForRent(em);
		
		//1-3 Display guitars details model, builder, colour and status of a selected model
		//1-4 Display guitar details colour, backwood, topwood, builder, type and status of a selected serialNumber
		//1-5 Display guitars details model, backwood, topwood and builder of a selected year of manufacture
		searchGuitarBy(em);
		searchGuitarBy(em);
		searchGuitarBy(em);
		//1-6 Update the information of a selected guitar ( Hint: search guitar by its serialNumber and allow to 
		//update its details, you need to check what details of a guitar are changeable.)
		updateGuitarInfo(em);
		
		//testing part 2
		System.out.println("Part Two: \n");
		//2-2 Rent Guitar/Guitars to a customer
		//2-3 Return Guitar/Guitars rented by a customer
		rentOrReturnGuitar(em);
		// 1-2 Display a list of guitars available for rent
		isAvailableForRent(em);
		//2-3 Return Guitar/Guitars rented by a customer
		rentOrReturnGuitar(em);
		//test rental display to check the rental system work
		for(Rental ren: rentals){
			ren.display();
		}

		//2-1 Display a list of guitar rented by a selected customer
		displayGuitarRentedByCustomer(em);

	    //2-4 Display the list of all guitars rented between two selected dates
		displayGuitarRentedBetweenTwoSelectedDates(em);
		
		
		//part 3
		System.out.println("Part three: \n");

		//3-1, 3-2, 3-4 View and update information of a selected customer or Employee
		//search Person by id
		searchPersonById(em);
		//View and update information of a selected customer or Employee
		viewAndUpdateOfAPerson(em);

		
	}
	//add employee
	private static Employee addEmployee() throws ParseException{
		//int id, String name, String address, String phone,Date birth, String officeAddress, String exPhone, String username, String password, boolean isAdmin
		//easy way to add employee
		Employee em1 = new Employee(1, "Ben", "Auckland", "0123456",sdf.parse("1990-11-01"),"Auckland", "0987654", "user1", "pwd1", true);
		Employee em2 = new Employee(2, "Jhon", "Auckland", "045678",sdf.parse("1995-4-25"),"Manukau", "0123456", "user2", "pwd2", false);
		employees.add(em1);
		employees.add(em2);
		persons.add(em1);
		persons.add(em2);
		return em1;
		//using scan method
		/*
		Employee em= null;
		System.out.println("Enter how many employee want to add: ");
		int number = scan.nextInt();
		for(int i =0; i < number; i++){
			System.out.println((i+1) +".");
			System.out.println("Enter ID: ");
			int id = scan.nextInt();
			System.out.println("Enter Name: ");
			String name = scan.next("[a-zA-Z]+");
			System.out.println("Enter Address: ");
			String add = scan.next();
			System.out.println("Enter Phone: ");
			String phone = scan.next();
			System.out.println("Enter date of birth: ");
			System.out.println("Enter Year: ");
			int year = scan.nextInt();
			System.out.println("Enter Month: ");
			int month = scan.nextInt()-1;
			System.out.println("Enter Date: ");
			int date = scan.nextInt();
			c.set(year, month, date);
			Date birth = c.getTime();
			System.out.println("Enter Office Address: ");
			String offAdd = scan.next();
			System.out.println("Enter extension phone: ");
			String exphone = scan.next();
			System.out.println("Enter User name: ");
			String userName = scan.next();
			System.out.println("Enter password: ");
			String pass = scan.next();
			System.out.println("Enter Role (Admin or staff): ");
			String input = scan.next();
			boolean role = false;
			if(input.toLowerCase().equals("admin")){
				role = true;
			}else if(input.toLowerCase().equals("staff")){
				role = false;
			}
			em =new Employee(id, name, add, phone, birth, offAdd, exphone, userName, pass, role);
			employees.add(em);
			persons.add(em);
		}
		return em;
		*/
	}
	//add Customer
	private static void addCustomer() throws ParseException{
		//(int id, String name, String address, String phone, Date birth, String licenceNum  ,Date licenceExpiryDate)
		//easy way to add customer
		Customer cust = new Customer(3, "Chris", "Auckland2", "0111111",sdf.parse("1995-4-25"),"L45789", sdf.parse("2018-11-14"));
		persons.add(cust);
		//using scan method
		/*
		Customer cust = null;
		System.out.println("Enter how many Customer want to add: ");
		int number = scan.nextInt();
		for(int i =0; i < number; i++){
			System.out.println((i+1) +".");
			System.out.println("Enter ID: ");
			int id = scan.nextInt();
			System.out.println("Enter Name: ");
			String name = scan.next("[a-zA-Z]+");
			System.out.println("Enter Address: ");
			String add = scan.next();
			System.out.println("Enter Phone: ");
			String phone = scan.next();
			System.out.println("Enter date of birth: ");
			System.out.println("Enter Year: ");
			int year = scan.nextInt();
			System.out.println("Enter Month: ");
			int month = scan.nextInt()-1;
			System.out.println("Enter Date: ");
			int date = scan.nextInt();
			c.set(year, month, date);
			Date birth = c.getTime();
			
			System.out.println("Enter licence Number: ");
			String licNum = scan.next();
			System.out.println("Enter licence Expiry Date: ");
			System.out.println("Enter Year: ");
			year = scan.nextInt();
			System.out.println("Enter Month: ");
			month = scan.nextInt()-1;
			System.out.println("Enter Date: ");
			date = scan.nextInt();
			c.set(year, month, date);
			Date  licenceED= c.getTime();
			cust =new Customer(id, name, add, phone, birth, licNum,licenceED);
			//employees.add(em);
			persons.add(cust);
		}
		*/
	}
	
	// add guitar
	private static void addGuitar(){
		//String serialNumber, double price, Builder builder,String model, Type type, Wood backWood, Wood topWood, int year, double rent, String colour 
		//easy way to add guitars
		Guitar guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Stratocaster", Type.ACOUSTIC, Wood.ADIRONDACK, Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		Guitar guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2011, 40,"Blue");
		Guitar guitar3 = new Guitar("3", 400, Builder.RYAN, "Stratocaster",Type.ACOUSTIC,Wood.ALDER,Wood.BRAZILIAN_ROSEWOOD,2016,30,"Black");
		guitars.add(guitar1);
		guitars.add(guitar2);
		guitars.add(guitar3);
		//using scan method
		/*
		System.out.println("Enter how many guitar want to add: ");
		int number = scan.nextInt();
		for(int i = 0; i<number; i++){
			System.out.println((i+1) +".");
			System.out.println("Enter Serial Number: " );
			String serNum = scan.next();
			System.out.println("Enter Price: ");
			double price = scan.nextDouble();
			System.out.println("Enter Model: ");
			String m = scan.next();
			
			System.out.println("Enter Type: " );
			Type type = Type.valueOf(scan.next().toUpperCase());
			System.out.println("Enter Builder: " );
			Builder builder = Builder.valueOf(scan.next().toUpperCase());
			System.out.println("Enter Colour: " );
			String colour = scan.next();
			System.out.println("Enter TopWood: " );
			Wood topWood = Wood.valueOf(scan.next().toUpperCase());
			System.out.println("Enter BackWood: ");
			Wood backWood = Wood.valueOf(scan.next().toUpperCase());
			System.out.println("Enter Year of manufacture: " );
			int year = scan.nextInt();
			System.out.println("Enter Rent rate per day: " );
			double rentRate = scan.nextDouble();
			Guitar guitar = new Guitar(serNum, price, builder,m, type, backWood, topWood, year, rentRate, colour );
			guitars.add(guitar);
		}
		*/
	}
	//this method ask for seach by model, serial number or year of manufacture
	private static void searchGuitarBy(Employee em){
		
		System.out.println("Search guitar/ guitars by model, serial number or year of manufacture: " );
		System.out.println("Enter M (model) or S(serial number) or Y(year of manufacture) or N (not search)" );
		char input = scan.next().toUpperCase().charAt(0);
		switch(input){
			case 'M':
				//model
				System.out.println("Enter the model to search guitars: " );
				try{
					String model = scan.next();
					em.searchGuitarsByModel(model.toLowerCase(),guitars);
				}catch(InputMismatchException  ex){
					System.out.println("Error: Wrong input type string ");
				}
				break;
			case 'S':
				//serial number
				System.out.println("Enter the serial number to search guitar: " );
				try{
					String serialNum = scan.next();
					em.displayGuitarBySerialNumber(serialNum.toLowerCase(),guitars);
				}catch(InputMismatchException  ex){
					System.out.println("Error: Wrong input type (string)");
				}
				break;
			case 'Y':
				//year of manufacture
				System.out.println("Enter the year of manufacture to search guitars: " );
				try{
					int year = scan.nextInt();
					em.searchGuitarsByYearOfManufacture(year,guitars);
				}catch(InputMismatchException  ex){
					System.out.println("Error: Wrong input type (int)");
				}
				break;
			case 'N':
				System.out.println("Exit\n");
				break;
			default:
				System.out.println("Error: Wrong input, please enter M/S/Y\n");
				break;	
		}
	}
	//is available for rent
	private static void isAvailableForRent(Employee em){
		System.out.println("\nDisplay list of guitars available for rent: \n");
		em.guitarsAvailableForRent(guitars);
	}
	//update guitar info
	private static void updateGuitarInfo(Employee em){
		System.out.println("Enter the serial number to update the infomation  of a selected guitar: ");
		try{
			String serialNum = scan.next();
			em.updateInfo(serialNum,guitars);
		}catch(InputMismatchException  ex){
			System.out.println("Error: Wrong input type (string)");
		}
	}
	//rent guitar or return guitar
	private static void rentOrReturnGuitar(Employee em){
		System.out.println("Rent or Return guitar: " );
		System.out.println("Enter Rent or Return " );
		String s= scan.next().toUpperCase();
		String sNum;
		switch(s){
			case "RENT":
				//rent
				System.out.println("Enter customer id to rent guitar:");
				int id = scan.nextInt();
				System.out.println("Enter guitar serial number:");
				sNum = scan.next();
				em.rentGuitar(sNum, id, guitars, rentals);
				break;
			case "RETURN":
				//return
				System.out.println("Enter serial number to return guitar:");
				sNum = scan.next();
				em.ReturnGuitar(sNum, rentals);
				break;
			default:
				System.out.println("Error: Wrong input, please enter Rent or Return");
				break;
		}

	}
	//guitar rented by a customer
	private static void displayGuitarRentedByCustomer(Employee em){
		System.out.println("Enter customer id to display a list of guitar rented by a selected customer:");
		int id = scan.nextInt();
		em.guitarsRentedbyCusotmer(id, rentals,persons);
	}
	//guitar rented between two selected dates
	private static void displayGuitarRentedBetweenTwoSelectedDates(Employee em){
		System.out.println("Display the list of all guitars rented between two selected dates: ");
		System.out.println("Enter start date follow by (yyyy-MM-dd): ");
		String s =scan.next();
		Date startDate;
		Date endDate;
		try {
			startDate = sdf.parse(s);
			System.out.println("Enter end date follow by (yyyy-MM-dd): ");
			s =scan.next();
			endDate = sdf.parse(s);
			em.displayRentedBetweenTwoSelectedDates(startDate, endDate, rentals);	
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//search person by id
	private static void searchPersonById(Employee em){
		System.out.println("Search Person detail (by ID): ");
		System.out.println("Enter ID: ");
		try{
			 int id = scan.nextInt();
			 //searchPerson return person
			 em.searchPerson(id, persons);
		}catch(InputMismatchException ex){
			System.out.println("Error: worng input ");
		}
	}
	////View and update information of a selected customer or Employee
	private static void viewAndUpdateOfAPerson(Employee em){
		System.out.println("View Person detail (by ID): ");
		System.out.println("Enter ID: ");
		try{
			 int id = scan.nextInt();
			 em.viewPersonInfoById(id, persons);
		}catch(InputMismatchException ex){
			System.out.println("Error: worng input ");
		}
	}

}
