import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import EmployeeAndCustomerManagement.Employee;
import StockManagement.Builder;
import StockManagement.Guitar;
import StockManagement.Type;
import StockManagement.Wood;

public class MethodsTest {
	
	@Test
	//display one guitar
	public void testDisplayOneGuitar() {
		Guitar guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Electric", Type.ACOUSTIC, Wood.ADIRONDACK, 
				Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		Guitar guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2015, 40,"Blue");
		Guitar guitar3 = new Guitar("3", 400, Builder.RYAN, "Stratocaster",Type.ACOUSTIC,Wood.ALDER,Wood.BRAZILIAN_ROSEWOOD,2016,30,"Black");
		//assertEquals([message,] expected, actual)
		//check guitar1
		assertEquals("Display guitar1 ","Serial Number: A123c" + "\nModel: Electric"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop",guitar1.display());
		//check guitar2
		assertEquals("Display guitar2 ","Serial Number: B784\nModel: Telecaster\nType: electric\nBuilder: Fender\nColour: Blue\nTopWood: Cedar\nBackWood: Sitka\nYear of manufacture: 2015\nPrice: 100.0\nRent rate per day: 40.0\nStatus: Shop",guitar2.display());
		//check guitar3
		assertEquals("Display guitar3 ","Serial Number: 3\nModel: Stratocaster\nType: acoustic\nBuilder: Ryan\nColour: Black\nTopWood: Brazilian Rosewood\nBackWood: Alder\nYear of manufacture: 2016\nPrice: 400.0\nRent rate per day: 30.0\nStatus: Shop",guitar3.display());
	}
	//displayGuitarsInfo
	@Test
	public void testDisplayGuitarsInfo() {
		// add one employee
		Calendar c = Calendar.getInstance();
		ArrayList<Guitar> guitars = new ArrayList<Guitar>();
		c.set(1990, 4, 5);
		Date dob = new Date();
		Employee em = new Employee(1, "Ben", "Auckland", "0123456",dob,"Auckland", "0987654", "user1", "pwd1", true);
		//add three guitars into guitars list
		Guitar guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Electric", Type.ACOUSTIC, Wood.ADIRONDACK, 
				Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		Guitar guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2015, 40,"Blue");
		guitars.add(guitar1);
		
		//testing one guitar
		String expected1 = "Display List of Guitars: \n"+"1.\n"+"Serial Number: A123c" + "\nModel: Electric"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n";
		assertEquals("Test one guitar1",expected1,em.displayGuitarsInfo(guitars) );
		
		guitars.add(guitar2);
		//testing two guitars
		String expected2 = "Display List of Guitars: \n"+"1.\n"+"Serial Number: A123c" + "\nModel: Electric"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n"+ "2.\n"+"Serial Number: B784\nModel: Telecaster\nType: electric\nBuilder: Fender\nColour: Blue\nTopWood: Cedar\nBackWood: Sitka\nYear of manufacture: 2015\nPrice: 100.0\nRent rate per day: 40.0\nStatus: Shop\n";
		assertEquals("Test two guitars",expected2,em.displayGuitarsInfo(guitars) );

	}
	
	//test Display a list of guitars available for rent
	@Test
	public void testGuitarsAvailableForRent() {
		// add one employee
		Calendar c = Calendar.getInstance();
		ArrayList<Guitar> guitars = new ArrayList<Guitar>();
		c.set(1990, 4, 5);
		Date dob = new Date();
		Employee em = new Employee(1, "Ben", "Auckland", "0123456",dob,"Auckland", "0987654", "user1", "pwd1", true);
		//add three guitars into guitars list
		Guitar guitar1 = new Guitar("A123c", 250, Builder.COLLINGS,"Electric", Type.ACOUSTIC, Wood.ADIRONDACK, 
				Wood.INDIAN_ROSEWOOD, 2011, 10, "Red" );
		Guitar guitar2 = new Guitar("B784", 100, Builder.FENDER, "Telecaster",Type.ELECTRIC,Wood.SITKA,Wood.CEDAR,2015, 40,"Blue");
		//test no guitar
		assertEquals("Test one guitar1",null,em.guitarsAvailableForRent(guitars) );
		guitars.add(guitar1);
		//testing one guitar
		String expected1 = "1.\n"+"Serial Number: A123c" + "\nModel: Electric"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n";
		assertEquals("Test one guitar1",expected1,em.guitarsAvailableForRent(guitars) );
		
		guitars.add(guitar2);
		//testing two guitars
		String expected2 = "1.\n"+"Serial Number: A123c" + "\nModel: Electric"+"\nType: acoustic"+ 
				"\nBuilder: Collings" +"\nColour: Red" + "\nTopWood: Indian Rosewood" + "\nBackWood: Adirondack"+
				"\nYear of manufacture: 2011" +"\nPrice: 250.0" +"\nRent rate per day: 10.0"+"\nStatus: Shop\n"+ "2.\n"+"Serial Number: B784\nModel: Telecaster\nType: electric\nBuilder: Fender\nColour: Blue\nTopWood: Cedar\nBackWood: Sitka\nYear of manufacture: 2015\nPrice: 100.0\nRent rate per day: 40.0\nStatus: Shop\n";
		assertEquals("Test two guitars",expected2,em.guitarsAvailableForRent(guitars) );

	}
}
