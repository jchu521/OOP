package RentalManagement;

import java.text.SimpleDateFormat;
import java.util.Date;

import EmployeeAndCustomerManagement.Customer;
import StockManagement.Guitar;

public class Rental {
	private Date rentDate,returnDueDate,returnDate;
	private int id;
	private Guitar guitar;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	//constructor
	public Rental(int id, Guitar guitar, Date rentDate, Date returnDueDate){
		this.id = id;
		this.guitar = guitar;
		this.rentDate = rentDate;
		this.returnDate = null;
		this.returnDueDate = returnDueDate;
	}
	//getter
	public Guitar getGuitar(){
		return guitar;
	}
	public int getid(){
		return id;
	}
	public Date getRentDate(){
		return rentDate;
	}
	public Date getReturnDueDate(){
		return returnDueDate;
	}
	public Date getReturnDate(){
		return returnDate;
	}
	//setter
	public void setReturnDate(Date returnDate){
		this.returnDate = returnDate;
	}
	public void setRentDate(Date rentDate){
		this.rentDate = rentDate;
	}
	public void setReturnDueDate(Date returnDueDate){
		this.returnDueDate = returnDueDate;
	}
	//display
	public void display(){
		System.out.println("Guitar: " + guitar.getSerialNumber());
		System.out.println("Rent Date: " + sdf.format(rentDate));
		System.out.println("Return Due Date: " + sdf.format(returnDueDate));
	}

}
